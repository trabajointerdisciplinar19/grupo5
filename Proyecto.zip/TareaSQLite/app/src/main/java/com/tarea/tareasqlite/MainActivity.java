//Main Activity
package com.tarea.tareasqlite;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText editTextPassword,editTextEmail;
    private Button buttonLogin;
    private ProgressDialog progressDialog;

    private TextView textViewRegister;

    private ManejadorBD mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(DatosCompartidos.getInstance(this).estaLogeado()){
            finish();
            startActivity(new Intent(getApplicationContext(),mostrador.class));
            Toast.makeText(getApplicationContext(), "Ya esta logeado!", Toast.LENGTH_LONG).show();
            return ;
        }

        editTextEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextPassword = (EditText) findViewById(R.id.editTextPassword);

        textViewRegister = (TextView) findViewById(R.id.textViewRegister);

        buttonLogin = (Button) findViewById(R.id.buttonEntrar);

        progressDialog = new ProgressDialog(this);

        buttonLogin.setOnClickListener(this);
        textViewRegister.setOnClickListener(this);

        mydb = new ManejadorBD(this);


    }

    private void loginUser(){
        final String email = editTextEmail.getText().toString().trim();
        final String password = editTextPassword.getText().toString().trim();

        progressDialog.setMessage("Espere por favor...");
        progressDialog.show();

        Cursor rs = mydb.obtenerDatos(email,password);

        if ((rs.moveToFirst()) && rs.getCount() !=0) {
            String nombre = rs.getString(rs.getColumnIndex(ManejadorBD.COLUMNA_NOMBRE));
            String telefono = rs.getString(rs.getColumnIndex(ManejadorBD.COLUMNA_TELEFONO));
            int id = rs.getInt(rs.getColumnIndex(ManejadorBD.COLUMNA_ID));
            if (!rs.isClosed()) {
                rs.close();
            }
            DatosCompartidos.getInstance(getApplicationContext()).guardarDatos(id, nombre, telefono, email);
            Toast.makeText(getApplicationContext(), "Contacto encontrado!", Toast.LENGTH_LONG).show();
            startActivity(new Intent(getApplicationContext(),mostrador.class));
            finish();
        }
        else{
            if (!rs.isClosed()) {
                rs.close();
            }
            progressDialog.hide();
            Toast.makeText(getApplicationContext(), "Contacto no encontrado!", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onClick(View v) {
        if(v == buttonLogin)
            loginUser();
        if(v == textViewRegister){
            finish();
            startActivity(new Intent(getApplicationContext(),registrarContacto.class));
        }
    }
}
