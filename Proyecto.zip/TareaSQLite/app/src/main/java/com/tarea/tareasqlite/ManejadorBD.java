//Manejador BD
package com.tarea.tareasqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class ManejadorBD extends SQLiteOpenHelper {

    public static final String NOMBRE_BASEDATOS = "Ejemplo";
    public static final String NOMBRE_TABLA = "contacto";
    public static final String COLUMNA_ID = "id";
    public static final String COLUMNA_NOMBRE = "nombre";
    public static final String COLUMNA_EMAIL = "email";
    public static final String COLUMNA_TELEFONO = "telefono";
    public static final String COLUMNA_PASSWORD= "password";


    public ManejadorBD(Context context) {
        super(context, NOMBRE_BASEDATOS , null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
            "create table contacto " +
                "(id integer primary key,password text, nombre text,telefono text,email text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS contacto");
        onCreate(db);
    }

    public boolean insertarContacto (String nombre, String telefono, String email,String pass) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("nombre", nombre);
        valores.put("telefono", telefono);
        valores.put("email", email);
        valores.put("password",pass);
        db.insert("contacto", null, valores);
        return true;
    }

    public Cursor obtenerDatos(String email,String pass) {
        SQLiteDatabase db = this.getReadableDatabase();
        //Cursor res =  db.rawQuery( "select * from contacto where email="+email+" and password="+pass+"", null );
        Cursor res = db.rawQuery("SELECT * FROM contacto WHERE email = ? AND password = ?", new String[] {email, pass});

        return res;
    }

    public boolean actualizarContacto(Integer id, String nombre, String telefono, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("nombre", nombre);
        valores.put("telefono", telefono);
        valores.put("email", email);
        db.update("contacto", valores, "id = ? ", new String[] { Integer.toString(id) } );
        return true;
    }
    public void eliminarContacto(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Integer res = db.delete("contacto", "id = ? ", new String[] { id });
        db.close();
    }
    public int contar(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor rs = db.rawQuery("SELECT * FROM contacto",null);
        return rs.getCount();
    }
}
