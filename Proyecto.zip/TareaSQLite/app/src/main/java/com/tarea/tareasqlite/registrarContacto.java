//Registrar Usuario
package com.tarea.tareasqlite;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class registrarContacto extends AppCompatActivity implements View.OnClickListener {

    private EditText editTextNombres,editTextContrasena,editTextCorreo,editTextTelefono;
    private Button buttonRegister,botonCancelar;

    private ProgressDialog progressDialog;

    private ManejadorBD mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_contacto);

        if(DatosCompartidos.getInstance(this).estaLogeado()){
            finish();
            startActivity(new Intent(getApplicationContext(),mostrador.class));
            Toast.makeText(getApplicationContext(), "Ya esta logeado!", Toast.LENGTH_LONG).show();
            return ;
        }

        editTextCorreo= (EditText) findViewById(R.id.editTextEmail);
        editTextNombres= (EditText) findViewById(R.id.editTextNombres);
        editTextContrasena = (EditText) findViewById(R.id.editTextContrasena);
        editTextTelefono = (EditText) findViewById(R.id.editTextTelefono);

        buttonRegister = (Button) findViewById(R.id.buttonRegister);
        botonCancelar = (Button) findViewById(R.id.botonCancelar);

        progressDialog = new ProgressDialog(this);

        mydb = new ManejadorBD(this);

        buttonRegister.setOnClickListener(this);
        botonCancelar.setOnClickListener(this);
    }

    private void registerUser(){
        final String email = editTextCorreo.getText().toString().trim();
        final String nombres = editTextNombres.getText().toString().trim();
        final String password = editTextContrasena.getText().toString().trim();
        final String telefono = editTextTelefono.getText().toString().trim();

        progressDialog.setMessage("Registering user...");
        progressDialog.show();

        if(mydb.insertarContacto(nombres,telefono,email,password)){
            Toast.makeText(getApplicationContext(), "Contacto creado!", Toast.LENGTH_LONG).show();
            finish();
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
        }
        else{
            Toast.makeText(getApplicationContext(), "Error al crear contacto!", Toast.LENGTH_LONG).show();
        }
    }
    @Override
    public void onClick(View v) {
        if(v == buttonRegister){
            registerUser();
        }
        if(v == botonCancelar){
            finish();
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
        }
    }
}
